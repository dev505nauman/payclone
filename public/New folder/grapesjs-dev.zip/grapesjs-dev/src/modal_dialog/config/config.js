export default {
  stylePrefix: 'mdl-',

  title: '',

  content: '',

  backdrop: true
};
