import Backbone from 'backbone';
import Category from './Category';

export default Backbone.Collection.extend({
  model: Category
});
