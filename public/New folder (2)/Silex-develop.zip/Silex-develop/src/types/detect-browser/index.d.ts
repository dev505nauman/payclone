declare module 'detect-browser' {
  export function detect(): any;
}
