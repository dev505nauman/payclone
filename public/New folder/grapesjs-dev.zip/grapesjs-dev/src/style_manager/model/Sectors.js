import Backbone from 'backbone';
import Sector from './Sector';

export default Backbone.Collection.extend({
  model: Sector
});
