import ComponentView from './ComponentView';

export default ComponentView.extend({
  events: {}
});
