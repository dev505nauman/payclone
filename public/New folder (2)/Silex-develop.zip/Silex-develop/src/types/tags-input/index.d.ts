declare module 'tags-input' {
  export default function tagsInput(input: HTMLInputElement): void;
}
