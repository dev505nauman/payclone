# Main Silex contributors

The new home for a list of [contributors to Silex website builder is in the wiki](https://github.com/silexlabs/Silex/wiki/Contributors)
