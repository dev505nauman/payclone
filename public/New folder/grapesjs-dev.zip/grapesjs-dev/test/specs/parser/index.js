import ParserHtml from './model/ParserHtml';
import ParserCss from './model/ParserCss';

describe('Parser', () => {
  ParserHtml.run();
  ParserCss.run();
});
