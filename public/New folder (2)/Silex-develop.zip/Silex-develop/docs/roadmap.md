## Road map

The new [home for road map of Silex website builder is in the wiki](https://github.com/silexlabs/Silex/wiki/Road-map)
