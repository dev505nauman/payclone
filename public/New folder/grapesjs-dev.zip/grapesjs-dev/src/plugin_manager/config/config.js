export default {
  plugins: []
};
