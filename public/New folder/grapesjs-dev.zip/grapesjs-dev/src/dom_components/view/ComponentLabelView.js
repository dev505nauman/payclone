import ComponentLinkView from './ComponentLinkView';

export default ComponentLinkView.extend({});
