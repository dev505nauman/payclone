export default {
  devices: [],

  deviceLabel: 'Device'
};
