import Backbone from 'backbone';
import Block from './Block';

export default Backbone.Collection.extend({
  model: Block
});
